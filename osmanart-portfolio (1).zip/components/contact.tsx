"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Mail, Phone, MapPin } from "lucide-react"

export function Contact() {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const name = formData.get("name")
    const email = formData.get("email")
    const message = formData.get("message")

    window.location.href = `mailto:contact@osmanart.com?subject=Inquiry from ${name}&body=${message}%0D%0A%0D%0AFrom: ${email}`
  }

  return (
    <section id="contact" className="py-24 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-16 text-center">
          <h2 className="text-5xl font-serif font-light mb-4" style={{ fontFamily: "var(--font-cormorant)" }}>
            Get in Touch
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Interested in commissioning a piece or learning more about available artwork? I'd love to hear from you.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-serif font-light mb-6" style={{ fontFamily: "var(--font-cormorant)" }}>
                Contact Information
              </h3>

              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <Mail className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <p className="font-medium mb-1">Email</p>
                    <a
                      href="mailto:contact@osmanart.com"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      contact@osmanart.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <p className="font-medium mb-1">Phone</p>
                    <a href="tel:+201234567890" className="text-muted-foreground hover:text-primary transition-colors">
                      +20 123 456 7890
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <MapPin className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <p className="font-medium mb-1">Studio</p>
                    <p className="text-muted-foreground">Cairo, Egypt</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-serif font-light mb-6" style={{ fontFamily: "var(--font-cormorant)" }}>
                Commission Process
              </h3>
              <div className="space-y-3 text-muted-foreground leading-relaxed">
                <p>1. Share your vision and requirements</p>
                <p>2. Receive a custom proposal and quote</p>
                <p>3. Approve the concept and timeline</p>
                <p>4. Receive progress updates during creation</p>
                <p>5. Final delivery and installation support</p>
              </div>
            </div>
          </div>

          <div>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" name="name" placeholder="Your name" required className="bg-background" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="your@email.com"
                  required
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  name="message"
                  placeholder="Tell me about your project or inquiry..."
                  rows={6}
                  required
                  className="bg-background resize-none"
                />
              </div>

              <Button type="submit" size="lg" className="w-full bg-primary hover:bg-primary/90">
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
