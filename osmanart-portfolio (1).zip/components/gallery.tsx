"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface Artwork {
  id: number
  title: string
  year: string
  medium: string
  dimensions: string
  price: string
  image: string
  description: string
  available: boolean
}

const artworks: Artwork[] = [
  {
    id: 1,
    title: "Sunset Reverie",
    year: "2024",
    medium: "Oil on Canvas",
    dimensions: '36" × 48"',
    price: "$2,500",
    image: "/abstract-sunset-painting-warm-colors.jpg",
    description: "A vibrant exploration of light and color inspired by Mediterranean sunsets.",
    available: true,
  },
  {
    id: 2,
    title: "Urban Echoes",
    year: "2024",
    medium: "Acrylic on Canvas",
    dimensions: '30" × 40"',
    price: "$1,800",
    image: "/abstract-urban-cityscape.png",
    description: "Capturing the rhythm and energy of city life through bold geometric forms.",
    available: true,
  },
  {
    id: 3,
    title: "Whispers of Nature",
    year: "2023",
    medium: "Mixed Media",
    dimensions: '24" × 36"',
    price: "$1,500",
    image: "/abstract-nature-inspired-painting-green-tones.jpg",
    description: "An organic composition celebrating the beauty of natural forms.",
    available: false,
  },
  {
    id: 4,
    title: "Midnight Dreams",
    year: "2023",
    medium: "Oil on Canvas",
    dimensions: '40" × 50"',
    price: "$3,200",
    image: "/abstract-dark-blue-night-painting.jpg",
    description: "A contemplative piece exploring the mystery of night and dreams.",
    available: true,
  },
  {
    id: 5,
    title: "Golden Hour",
    year: "2024",
    medium: "Acrylic on Canvas",
    dimensions: '32" × 42"',
    price: "$2,100",
    image: "/abstract-golden-yellow-painting-warm-light.jpg",
    description: "Celebrating the magical quality of light during the golden hour.",
    available: true,
  },
  {
    id: 6,
    title: "Serenity",
    year: "2023",
    medium: "Watercolor on Paper",
    dimensions: '18" × 24"',
    price: "$950",
    image: "/abstract-serene-blue-watercolor-painting.jpg",
    description: "A peaceful composition evoking calm and tranquility.",
    available: true,
  },
]

export function Gallery() {
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null)

  return (
    <section id="gallery" className="py-24 px-6">
      <div className="container mx-auto">
        <div className="mb-16 text-center">
          <h2 className="text-5xl font-serif font-light mb-4" style={{ fontFamily: "var(--font-cormorant)" }}>
            Gallery
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Explore a curated selection of contemporary paintings. Each piece is available for purchase or commission.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {artworks.map((artwork) => (
            <Card
              key={artwork.id}
              className="group cursor-pointer overflow-hidden border-0 shadow-sm hover:shadow-lg transition-all duration-300"
              onClick={() => setSelectedArtwork(artwork)}
            >
              <div className="relative aspect-[3/4] overflow-hidden bg-muted">
                <img
                  src={artwork.image || "/placeholder.svg"}
                  alt={artwork.title}
                  className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
                />
                {!artwork.available && (
                  <div className="absolute top-4 right-4 bg-foreground text-background px-3 py-1 text-xs font-medium rounded-sm">
                    Sold
                  </div>
                )}
              </div>
              <div className="p-6 space-y-2">
                <h3 className="text-xl font-serif font-medium" style={{ fontFamily: "var(--font-cormorant)" }}>
                  {artwork.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {artwork.year} • {artwork.medium}
                </p>
                <p className="text-lg font-medium text-primary">{artwork.price}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <Dialog open={!!selectedArtwork} onOpenChange={() => setSelectedArtwork(null)}>
        <DialogContent className="max-w-4xl">
          {selectedArtwork && (
            <div className="grid md:grid-cols-2 gap-8">
              <div className="relative aspect-[3/4] rounded-sm overflow-hidden bg-muted">
                <img
                  src={selectedArtwork.image || "/placeholder.svg"}
                  alt={selectedArtwork.title}
                  className="object-cover w-full h-full"
                />
              </div>
              <div className="space-y-6">
                <DialogHeader>
                  <DialogTitle
                    className="text-3xl font-serif font-light"
                    style={{ fontFamily: "var(--font-cormorant)" }}
                  >
                    {selectedArtwork.title}
                  </DialogTitle>
                </DialogHeader>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Year</p>
                    <p className="font-medium">{selectedArtwork.year}</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Medium</p>
                    <p className="font-medium">{selectedArtwork.medium}</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Dimensions</p>
                    <p className="font-medium">{selectedArtwork.dimensions}</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Price</p>
                    <p className="text-2xl font-medium text-primary">{selectedArtwork.price}</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Description</p>
                    <p className="leading-relaxed">{selectedArtwork.description}</p>
                  </div>
                </div>

                <div className="pt-4">
                  {selectedArtwork.available ? (
                    <Button asChild className="w-full bg-primary hover:bg-primary/90">
                      <a href={`mailto:contact@osmanart.com?subject=Inquiry about ${selectedArtwork.title}`}>
                        Inquire About This Piece
                      </a>
                    </Button>
                  ) : (
                    <Button disabled className="w-full">
                      Sold
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}
