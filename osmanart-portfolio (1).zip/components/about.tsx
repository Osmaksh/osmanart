export function About() {
  return (
    <section id="about" className="py-24 px-6 bg-muted/30">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative aspect-square rounded-sm overflow-hidden">
            <img src="/artist-portrait-in-studio-with-paintings.jpg" alt="Osman Rafaat in studio" className="object-cover w-full h-full" />
          </div>

          <div className="space-y-6">
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground tracking-widest uppercase">About the Artist</p>
              <h2 className="text-5xl font-serif font-light" style={{ fontFamily: "var(--font-cormorant)" }}>
                Osman Rafaat
              </h2>
            </div>

            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Osman Rafaat is a contemporary artist based in Cairo, Egypt, whose work explores the dynamic
                relationship between color, form, and emotion. With over a decade of experience, his paintings have been
                exhibited in galleries across the Middle East and Europe.
              </p>

              <p>
                Drawing inspiration from both traditional and modern artistic movements, Osman creates pieces that
                bridge cultural narratives with contemporary aesthetics. His work is characterized by bold color
                palettes, expressive brushwork, and a deep exploration of light and shadow.
              </p>

              <p>
                Each painting is a meditation on the human experience, inviting viewers to find their own meaning within
                the abstract forms and vibrant compositions. Osman's work is held in private collections worldwide and
                continues to evolve with each new series.
              </p>
            </div>

            <div className="pt-4">
              <h3 className="text-lg font-medium mb-3">Education & Recognition</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• MFA in Fine Arts, Cairo University (2015)</li>
                <li>• Featured in Contemporary Art Magazine (2023)</li>
                <li>• Solo Exhibition, Alexandria Art Gallery (2022)</li>
                <li>• Emerging Artist Award, Cairo Biennale (2020)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
