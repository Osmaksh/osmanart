import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 pt-24">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground tracking-widest uppercase">Contemporary Artist</p>
              <h1
                className="text-6xl lg:text-7xl font-serif font-light leading-tight text-balance"
                style={{ fontFamily: "var(--font-cormorant)" }}
              >
                Osman Rafaat
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed text-pretty max-w-xl">
                Creating contemporary art that explores the intersection of emotion, color, and form. Each piece tells a
                unique story.
              </p>
            </div>

            <div className="flex gap-4">
              <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
                <Link href="#gallery">View Gallery</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="#contact">Commission Work</Link>
              </Button>
            </div>
          </div>

          <div className="relative aspect-[3/4] rounded-sm overflow-hidden">
            <img src="/contemporary-abstract-painting-with-warm-colors.jpg" alt="Featured artwork" className="object-cover w-full h-full" />
          </div>
        </div>
      </div>
    </section>
  )
}
